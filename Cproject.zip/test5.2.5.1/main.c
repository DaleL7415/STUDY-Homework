#include <stdio.h>
#include <string.h>
void strnins(char s[],char t[],int n){
     int i,j=strlen(t);
     int a,b;
     char new[1000];
     for(a=0;a<n;a++)
     new[a]=s[a];
     for(b=0;b<j;b++)
     new[a+b]=t[b];
     for(i=n;i<strlen(s);i++)
     new[b+i]=s[i];
     new[b+i]='\0';
     for(a=0;a<(i+j);a++)
     putchar(new[a]);
     putchar('\n');
}
int main()
{
    char s[100],t[100];
    scanf("%s%s",&s,&t);
    int n;
    scanf("%d",&n);
    strnins(s,t,n);
    return 0;
}
