#include <stdio.h>
#include <stdlib.h>
int main()
{
    int x,a;
    scanf("%d",&x);
    do{
        a=x%10;
        x=x/10;
        printf("%d",a);
    }while(x!=0);
    return 0;
}
