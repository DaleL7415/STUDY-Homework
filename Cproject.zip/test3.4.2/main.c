#include <stdio.h>
int main()
{
    int a,y,j,i,z;
    scanf("%d",&a);
    for(i=1;i<(a/2);i++){
        for(y=2;y<i;y++)
        if(i%y==0) break;
        if(i==y){
        z=a-y;
        for(j=2;j<z;j++)
        if(z%j==0) break;
        if(z==j)
        printf("%d=%d+%d\t",a,y,z);
        }
        }
        return 0;
}
