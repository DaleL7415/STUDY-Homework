#include <stdio.h>
#include <stdlib.h>
#define N 20
#define M 10
int main()
{
   char a[M+N+2],b[M+N+2],*p1=a,*p2=b;
   int i,s[M+N+2],k=0;
   for(i=0;i<M+N+2;i++)
        s[i]=0;
   for(i=0;i<M+N+2;i++)
   scanf("%c",p1+i);
   *(p1+M+N+1)='\0';
   for(i=0;i<M+N+2;i++)
   scanf("%c",p2+i);
   *(p2+M+N+1)='\0';
   for(i=M+N;i>=0;i--){
        if(*(p1+i)=='.') i--;
             int x=0,m,n;
             m=*(p1+i)-'0';
             n=*(p2+i)-'0';
             x=m+n+k;
             if(x>=10){
                  k=x/10;
                  *(s+i+1)=x%10;
             }
             else{
                  *(s+i+1)=x%10;
                  k=0;
             }
           }
    *(s+0)=k;
    for(i=0;i<M+N+2;i++){
         if(i==N+1)
         putchar('.');
         else
         printf("%d",*(s+i));}
    return 0;
   }
