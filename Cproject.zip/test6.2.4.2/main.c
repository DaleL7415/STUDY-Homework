#include <stdio.h>
#include <string.h>
int fs(char p[][80],int i,int y){
     static int k=0;
     int j;
     if(*(p[i]+y)=='\0') return 0;
     else if(k==-1){
          if(*(p[i]+y)==' '){
          for(j=0;*(p[i]+(y+j));j++)
          *(p[i]+y+j)=*(p[i]+(y+j+1));
          return fs(p,i,y);}
          else
               k=0;
          }
     else if(*(p[i]+y)==' ')
          k=-1;
          return fs(p,i,y+1);
}
int main()
{
    int n,i,j;
    scanf("%d",&n);
    getchar();
    char c[n][80],(*p)[80]=c;
    for(i=0;i<n;i++){
    gets(c[i]);
    strcpy(p[i],c[i]);
    fs(p,i,0);}
    for(i=0;i<n;i++){
    if((*(p[i]+0)!=' '||*(p[i]+1)!='\0')&&*(p[i]+0)!='\0'){
    for(j=0;*(p[i]+j);j++)
    putchar(*(p[i]+j));
    putchar('\0');
    putchar('\n');}
    }

    return 0;
}
