#include <stdio.h>
#include <string.h>
#include <stdlib.h>
struct score_tab{
     long num;
     char name[20];
     float eng,math,phy,C;
     float sum;
     float avr;
     struct score_tab *next;
};
struct score_tab * f_int(struct score_tab *headp){
     struct score_tab *loc_head=NULL,*tail;
     long n;
     printf("����ѧ�ţ�������Ӣ���ѧ��������C���Գɼ�\n");
     scanf("%ld",&n);
     loc_head=(struct score_tab *)malloc(sizeof(struct score_tab));
     loc_head->num=n;
          scanf("%s%f%f%f%f",loc_head->name,&loc_head->eng,&loc_head->math,&loc_head->phy,&loc_head->C);
          loc_head->next=NULL;
          tail=loc_head;
          headp=loc_head;
          while(scanf("%ld",&n)&&n){
               loc_head=(struct score_tab *)malloc(sizeof(struct score_tab));
               loc_head->num=n;
               scanf("%s%f%f%f%f",loc_head->name,&loc_head->eng,&loc_head->math,&loc_head->phy,&loc_head->C);
               loc_head->next=NULL;
               tail->next=loc_head;
               tail=tail->next;
          }
     return headp;
}
void f_pri(struct score_tab *headp)
{
     struct score_tab *tail;
     tail=headp;
     while(tail!=NULL){
     printf("%ld   %s   %.2f   %.2f   %.2f   %.2f\n",tail->num,tail->name,tail->eng,tail->math,tail->phy,tail->C);
     tail=tail->next;
     }
}
void f_order(struct score_tab *headp){
     char N[20];
     long n;
     float a,b,c,d,sum;
     struct score_tab *p=headp,*p1;
     int len=0,i,j;
     while(p){
          len++;
          p=p->next;}
     for(i=0,p=headp;i<len-1;i++,p=p->next){
     for(j=0,p1=headp;j<len-i-1;j++,p1=p1->next){
          p1->sum=p1->eng+p1->math+p1->phy+p1->C;
          p1->avr=p1->sum/4.0;
          p1->next->sum=p1->next->eng+p1->next->math+p1->next->phy+p1->next->C;
          p1->next->avr=p1->next->sum/4.0;
          if(p1->avr>p1->next->avr){
               n=p1->num,p1->num=p1->next->num,p1->next->num=n;
               strcpy(N,p1->name),strcpy(p1->name,p1->next->name),strcpy(p1->next->name,N);
               a=p1->eng,p1->eng=p1->next->eng,p1->next->eng=a;
               b=p1->math,p1->math=p1->next->math,p1->next->math=b;
               c=p1->phy,p1->phy=p1->next->phy,p1->next->phy=c;
               d=p1->C,p1->C=p1->next->C,p1->next->C=d;
          }

     }
}}
void f_avr(struct score_tab *headp){
     struct score_tab *p=headp;
     while(p!=NULL){
          p->sum=p->eng+p->math+p->phy+p->C;
          p->avr=p->sum/4.0;
          printf("%s��ƽ����%.2f\n",p->name,p->avr);
          p=p->next;
     }
}

int main()
{
    struct score_tab *headp=NULL;
    headp=f_int(headp);
    f_avr(headp);
    f_order(headp);
    printf("�����:\n");
    f_pri(headp);
    return 0;
}
