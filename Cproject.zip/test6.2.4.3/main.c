#include <stdio.h>
#include <stdlib.h>
#define N 8
#define M 3
void cour_ave(int sco[N][M],char cour[M][100]);
void stu_ave(int sco[N][M]);
void lower(int sco[N][M],char cour[M][100]);
void f(int sco[N][M],char cour[M][100]);
int main()
{
    char cour[M][100];
    int sco[N][M];
    int i,j;
    for(i=0;i<M;i++)
    scanf("%s",cour+i);
    for(i=0;i<N;i++){
         for(j=0;j<M;j++)
         scanf("%d",(sco[i]+j));
    }
    cour_ave(sco,cour);
    stu_ave(sco);
    lower(sco,cour);
    f(sco,cour);
    return 0;
}
void cour_ave(int sco[N][M],char cour[M][100]){//ÿ�ſ�ƽ���ɼ�
     int i,j,sum;
     for(i=0;i<M;i++){
          sum=0;
          for(j=0;j<N;j++)
          sum+=(*(sco[j]+i));
          printf("%s��ƽ���ɼ���%d\n",*(cour+i),sum/N);
     }
}
void stu_ave(int sco[N][M]){//ÿ��ѧ����ƽ���ɼ�
     int i,j,sum;
     printf("ÿ��ѧ����ƽ���ɼ�:");
     for(i=0;i<N;i++){
          sum=0;
          for(j=0;j<M;j++)
          sum+=(*(sco[i]+j));
          printf("%d   ",sum/M);
     }
     putchar('\n');
}
void lower(int sco[N][M],char cour[M][100]){//ÿ�ſ�û��ƽ���ֵ�ѧ������
     int i,j,k,sum;
     for(i=0;i<M;i++){
          k=0,sum=0;
          for(j=0;j<N;j++)
          sum+=(*(sco[j]+i));
          for(j=0;j<N;j++)
          if(*(sco[j]+i)<(sum/N))
          k++;
          printf("%sû��ƽ���ֵ�ѧ������Ϊ%d\n",*(cour+i),k);
}}
void f(int sco[N][M],char cour[M][100]){
     int i,j,n,m;
     for(i=0;i<M;i++){
          n=0,m=0;
          for(j=0;j<N;j++){
               if(*(sco[j]+i)<60)
               n++;
               else if(*(sco[j]+i)>=90)
               m++;
          }
     printf("%s����������%d\n",*(cour+i),n);
     printf("%s90����������%d\n",*(cour+i),m);
     }
}

