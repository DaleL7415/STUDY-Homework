#include<stdio.h>
int main(){
unsigned long x,a,b,c,d;
    scanf("%lu",&x);
    a=x>>24;
    b=x<<8>>24;
    c=x<<16>>24;
    d=x<<24>>24;
    printf("%lu.%lu.%lu.%lu",d,c,b,a);
    return 0;
}
