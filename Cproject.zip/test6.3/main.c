#include <stdio.h>
#include <stdlib.h>

int main(int argc,char *argv[]){
     int n=0;
     while(n<argc){
          printf("%s\n",argv[n]);
          n++;
     }
     printf("the number of cmmand-line arguments are %d\n",argc);
     return 0;
}
