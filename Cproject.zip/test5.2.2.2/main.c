#include<stdio.h>
#define M 10
#define N 3
int main(void)
{
     int a[M], b[M];
     int i, j, k;
     for(i = 0; i < M; i++)
        a[i] = i + 1;
        for(i=M,j=0;i>1;i--){
             for(k=1;k<=N;){
             if(a[j]!=0)
             k++;
             if(++j>M-1)
             j=0;}
             b[M-i]=j?a[j-1]:a[M-1];
             if(j)
             a[j-1]=0;
             else
             a[M-1]=0;}
             for(i=0;i<M-1;i++)
             printf("%6d",b[i]);
             for(i=0;i<M;i++)
             if(a[i]!=0)
             printf("%6d",a[i]);
             return 0;
}
