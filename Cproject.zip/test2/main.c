#include <stdio.h>
#include <math.h>
#define a 1e-5
int main (void){
    double d=0.0,n=0.0;
   do {
       d+=(pow((-1),n))*(1/(2*n+1));
       n++;
}while(fabs((pow((-1),(n-1)))*(1/(2*(n-1)+1)))>=a);
printf("%.9f\n",4*d);
return 0;
}
