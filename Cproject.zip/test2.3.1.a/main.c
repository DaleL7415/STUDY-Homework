#include <stdio.h>
int main()
{
    double x,tax=0.0;
    scanf("%lf",&x);
    switch((int)x/1000){
        case 0:
        printf("%lf",tax);break;
        case 1:
        printf("%lf",0.05*(x-1000));break;
        case 2:
        printf("%lf",0.10*(x-2000)+50.0);break;
        case 3:
        printf("%lf",0.15*(x-3000)+150.0);break;
        case 4:
        printf("%lf",0.20*(x-4000)+300.0);break;
        default:
        printf("%lf",0.25*(x-5000)+500.0);break;
    }
    return 0;
}
