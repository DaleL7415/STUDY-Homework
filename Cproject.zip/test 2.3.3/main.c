#include <stdio.h>
#include <stdlib.h>
int C(int n){
    int a,b;
    for(a=b=1;b<=n;b++)
        a*=b;
    return a;
}
int main()
{
    int i,j,k,x;
    for(i=0;i<10;i++){
        for(k=1;k<=18-2*i;++k){
            printf(" ");
        }
        for(j=0;j<=i;++j){
            x=C(i)/(C(j)*C(i-j));
            printf("%-4d",x);
        }
        printf("\n");
    }
    return 0;
}
