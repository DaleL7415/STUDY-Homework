#include <stdio.h>
#include <math.h>
#define EPS 1e-6

int main(void)
{
    double a,x;
    scanf("%lf",&a);
    do{
        x=-((((3*a-4)*a)-5)*a+13)/((9*a-8)*a-5);
        a+=x;
    }while(fabs(x)>EPS);
    printf("%lf\n",a);
    return 0;
}
