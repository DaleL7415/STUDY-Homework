#include <stdio.h>
#include <string.h>
int BinarySearch(int a[],int x,int n){
     int m,i=0,j=n-1;
     if(i<=j){
     m=(i+j)/2;
     if(x<a[m])
     i=m+1;
     else if(x>a[m])
     j=m-1;
     else
     return m;}
     else
     return -1;
}
int main()
{
    int n,t,j;
    scanf("%d",&n);
    char name[1000][20],s[20];
    int score[n],i;
    for(i=0;i<n;i++){
    scanf("%s",&name[i]);
    scanf("%d",&score[i]);
    getchar();
    }
    for(i=0;i<n-1;i++)
    for(j=0;j<n-i-1;j++)
    if(score[j]<score[j+1]){
    t=score[j+1],score[j+1]=score[j],score[j]=t;
    strcpy(s,name[j]),strcpy(name[j],name[j+1]),strcpy(name[j+1],s);}
    for(i=0;i<n;i++)
    printf("%s:%d ",name[i],score[i]);
    putchar('\n');
    int x,c;
    scanf("%d",&x);
    c=BinarySearch(score,x,i);
    if(c!=-1)
    printf("%s:%d\n",name[c],score[c]);
    else
    printf("Not find!\n");

    return 0;
}








