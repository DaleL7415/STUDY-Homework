#include <stdio.h>
#define BEGIN 10
#define END 20
int main()
{
    int a,y,j,i,z;
    for(a=BEGIN;a<=END;a=a+2)
    for(i=1;i<=(a/2);i++){
        for(y=2;y<i;y++)
        if(i%y==0) break;
        if(i==y){
        z=a-y;
        for(j=2;j<=z;j++)
        if(z%j==0) break;
        if(z==j){
        printf("%d=%d+%d\n",a,y,z);break;
        }
        }
        }

        return 0;
}
