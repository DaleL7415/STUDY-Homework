#include <stdio.h>
#include <stdlib.h>
#define CHANGE 0

int main(void)
{
    char s[1000];
    int i=0;
    while((s[i]=getchar())!='\n'){
    #if CHANGE==1
    if(s[i]>='a'&&s[i]<='z')
     putchar(s[i]-32);
     else if(s[i]>='A'&&s[i]<='Z')
     putchar(s[i]+32);
     else
     putchar(s[i]);
    #else
     putchar(s[i]);
    #endif
    i++;
    }s[i]='\0';
    putchar('\n');
    return 0;
}
