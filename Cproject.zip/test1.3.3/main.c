#include<stdio.h>
int main(){
        unsigned long x;
        int a,i=0;
        scanf("%lu",&x);
        do{
        a=x%256;
        if(i<3)
        printf("%d.",a);
        else
        printf("%d",a);
        i+=1;
        }
        while((x/=256)!=0);
        putchar('\n');
    return 0;
}
