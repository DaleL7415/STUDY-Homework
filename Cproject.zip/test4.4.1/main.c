#include <stdio.h>
#include <math.h>
#define s(a,b,c) (((a)+(b)+(c))/2)
#define area(a,b,c,s) (sqrt((s)*((s)-(a))*((s)-(b))*((s)-(c))))
int main()
{
    int a,b,c;
    double t;
    scanf("%d%d%d",&a,&b,&c);
    t=s(a,b,c);
    t=area(a,b,c,t);
    printf("area=%lf\n",t);
    return 0;
}
