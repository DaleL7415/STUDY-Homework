#include <stdio.h>
int main(void){
    int i,n,a[20];
    while((scanf("%d",&n))!=0){
    if(n>=3)
{
    a[0]=1;
    a[1]=1;
    for(i=2;i<n;i++){
    a[i]=a[i-1]+a[i-2];
    for(i=0;i<n;i++){
    if(i%8==0&&i!=0) putchar('\n');
        printf("% 10d",a[i]);}
}
    printf("\n");}
if(n>0&&n<3)
    printf("Error!\n");
}
return 0;
}
