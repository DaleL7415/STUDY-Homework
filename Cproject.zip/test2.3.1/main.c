#include <stdio.h>
 int main (){
     double x,tax=0.0;
     scanf("%lf",&x);
     if (x<1000)
     printf("%lf",tax);
     else if(x<2000)
     printf("%lf",0.05*(x-1000));
     else if(x<3000)
     printf("%lf",0.10*(x-2000)+50.0);
     else if(x<4000)
     printf("%lf",0.15*(x-3000)+150.0);
     else if(x<5000)
     printf("%lf",0.20*(x-4000)+300.0);
     else
     printf("%lf",0.25*(x-5000)+500.0);
     return 0;
 }
