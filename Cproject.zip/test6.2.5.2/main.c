#include <stdio.h>
#include <string.h>

int main()
{   int n;
    scanf("%d",&n);
    char *(*p[2])(const char *,const char *);
     p[0]=strpbrk;
     p[1]=strstr;
    char a[20]="abcdef",b[20]="def",*c;
    if(n>=2||n<0){
    printf("Wrong!\n");
    return 0;
  }
    else
    c=(*p[n])(a,b);
    printf("%s\n",c);
    return 0;
}
