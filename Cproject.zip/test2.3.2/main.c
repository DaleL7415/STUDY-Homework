#include <stdio.h>
#include <stdlib.h>
int main()
{
    char s;
    int a=0;
    while((s=getchar())!=EOF){
    if(s==' '){
        if(a==0){
            putchar(s);
            a=1;
        }
    }
    if(s!=' '){
        a=0;
        putchar(s);
        }
    }
    return 0;
}
