#include <stdio.h>
#include <stdlib.h>

int main()
{
    int num[3][4],n,m;
    for(n=0;n<3;n++)
    for(m=0;m<4;m++)
    scanf("%d",&num[n][m]) ;
    printf("ԭ����:\n");
    for(n=0;n<3;n++){
    for(m=0;m<4;m++)
    printf("%6d",num[n][m]);
    putchar('\n');}
    printf("ת�þ���:\n");
    for(n=0;n<4;n++){
    for(m=0;m<3;m++)
    printf("%6d",num[m][n]);
        putchar('\n');}
    return 0;
}
