#include <stdio.h>
 void main(void)
  {
  int s;
  scanf("%d",&s);
  int i=1,a=1;
  do{
     a=a*i;
     i++;
  }while(a<s);
  printf("%d",i-1);
  }
