#include <stdio.h>
int main(void)
{
    int t;
    float a,b;
    char i;
    while((scanf ("%d %f %f %c",&t,&a,&b,&i))!=EOF&&a!=0.0&&b!=0.0&&a>=-100000.0&&a<=100000.0&&b>=-100000.0&&b<=100000.0){
    if (t==0){
    if(i=='+')
    printf("After if-else processing,the result is : %.2f\n",a+b);
    if(i=='-')
    printf("After if-else processing,the result is : %.2f\n",a-b);
    if(i=='*')
    printf("After if-else processing,the result is : %.2f\n",a*b);
    if(i=='/')
    printf("After if-else processing,the result is : %.2f\n",a/b);
    }
    if(t==1){
        switch (i){
        case '+':
        printf("After switch processing,the result is : %.2f\n",a+b);break;
        case '-':
        printf("After switch processing,the result is : %.2f\n",a-b);break;
        case '*':
        printf("After switch processing,the result is : %.2f\n",a+b);break;
        case '/':
        printf("After switch processing,the result is : %.2f\n",a/b);break;
        }
    }
    if(t==2){
    switch (i){
    case '+':
    printf("After if-else processing,the result is : %.2f\n",a+b);
    printf("After switch processing,the result is : %.2f\n",a+b);break;
    case '-':
    printf("After if-else processing,the result is : %.2f\n",a-b);
    printf("After switch processing,the result is : %.2f\n",a-b);break;
    case '*':
    printf("After if-else processing,the result is : %.2f\n",a*b);
    printf("After switch processing,the result is : %.2f\n",a*b);break;
    case '/':
    printf("\nAfter if-else processing,the result is : %.2f\n",a/b);
    printf("After switch processing,the result is : %.2f\n",a/b);break;
    }
    }
    }printf("\n");
    return 0;
}
