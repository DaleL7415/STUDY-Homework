#include <stdio.h>

int main()
{
    long x=0x1234ABCD,i;
    char low,high;
    char *p=(char *)&x;
    for(i=3;i>=0;i--){
         high=(*(p+i)>>4)&0x0f;
         if(high<10)
         high=high+'0';
         else
         high=high-10+'A';
         low=*(p+i)&0x0f;
         if(low<10)
         low=low+'0';
         else
         low=low-10+'A';
         putchar(high);
         putchar(' ');
         putchar(' ');
         putchar(low);
         putchar('\n');
    }
    return 0;
}
