#include <stdio.h>
#include <string.h>
#include <stdlib.h>
struct score_tab{
     long num;
     char name[20];
     float eng,math,phy,C;
     float sum;
     float avr;
     struct score_tab *prior;
     struct score_tab *next;
};

void f_int(struct score_tab **headp){
     struct score_tab *loc_head=NULL,*tail;
     long n;
     printf("����ѧ�ţ�������Ӣ���ѧ��������C���Գɼ�\n");
     scanf("%ld",&n);
          loc_head=(struct score_tab *)malloc(sizeof(struct score_tab));
          loc_head->num=n;
          scanf("%s%f%f%f%f",loc_head->name,&loc_head->eng,&loc_head->math,&loc_head->phy,&loc_head->C);
          tail=loc_head;
          while(scanf("%ld",&n)&&n){
               tail->next=(struct score_tab *)malloc(sizeof(struct score_tab));
               tail->next->prior=tail;
               tail=tail->next;
               tail->num=n;
               scanf("%s%f%f%f%f",tail->name,&tail->eng,&tail->math,&tail->phy,&tail->C);
          }
          tail->next=loc_head;
          loc_head->prior=tail;
    *headp=loc_head;
}
void f_pri(struct score_tab *headp)
{
     struct score_tab *p;
     p=headp;
     do{
     printf("%ld   %s   %.2f   %.2f   %.2f   %.2f\n",p->num,p->name,p->eng,p->math,p->phy,p->C);
     p=p->next;
     }while(p->prior!=headp->prior);
}
void f_cor(struct score_tab *headp,int n){
     struct score_tab *p=headp;
     char N[20],M[20],t[20];
     long a,b,c,d,e,f;
     int i;
     float eng1,math1,phy1,C1;
     switch(n){
          case 1://�޸�ѧ��
          scanf("%s",N);
          i=0;
          while(p->name[i]!=*(N+i++)&&p->next!=headp->prior)
          p=p->next;
          if(p->next==headp->prior) printf("Worry!\n");
          else{
               scanf("%ld",&a);
               p->num=a;
          } break;
          case 2://�޸�����

          scanf("%ld",&b);
          while(p->num!=b&&p->next!=headp->prior)
          p=p->next;
          if(p->next==headp->prior) printf("Worry!\n");
          else{
               gets(M);
               strcpy(t,M),strcpy(p->name,t),strcpy(M,p->name);
          } break;
          case 3://�޸�Ӣ��ɼ�
          scanf("%ld",&c);
          while(p->num!=c&&p->next!=headp->prior)
          p=p->next;
          if(p->next==headp->prior) printf("Worry!\n");
          else{
               scanf("%f",&eng1);
               p->eng=eng1;
          } break;
          case 4://�޸���ѧ�ɼ�
          scanf("%ld",&d);
          while(p->num!=d&&p->next!=headp->prior)
          p=p->next;
          if(p->next==headp->prior) printf("Worry!\n");
          else{
               scanf("%f",&math1);
               p->math=math1;
          } break;
          case 5://�޸������ɼ�

          scanf("%ld",&e);
          while(p->num!=e&&p->next!=headp->prior)
          p=p->next;
          if(p->next==headp->prior) printf("Worry!\n");
          else{
               scanf("%f",&phy1);
               p->phy=phy1;
          } break;
          case 6://�޸�C���Գɼ�
          scanf("%ld",&f);
          while(p->num!=f&&p->next!=headp->prior)
          p=p->next;
          if(p->next==headp->prior) printf("Worry!\n");
          else{
               scanf("%f",&C1);
               p->C=C1;
          } break;
          default:printf("Worry!\n"); break;

     }
}
void f_sum(struct score_tab *headp){
     struct score_tab *p;
     p=headp;
     do{
          p->sum=p->eng+p->math+p->phy+p->C;
          printf("  %s ���ܷ�%.2f\n",p->name,p->sum);
          p=p->next;
     } while(p->prior!=headp->prior);
}
void f_avr(struct score_tab *headp){
     struct score_tab *p=headp;
     do{
          p->sum=p->eng+p->math+p->phy+p->C;
          p->avr=p->sum/4.0;
          printf("  %s ��ƽ����%.2f\n",p->name,p->avr);
          p=p->next;
     } while(p->prior!=headp->prior);

}
int main()
{
    struct score_tab *headp=NULL,*head;
    f_int(&headp);
    head=headp;
    f_pri(head);
    int n;
    printf("�������޸�ѡ��:\n");
    printf("1:�޸�ѧ��       2:�޸�����       3:�޸�Ӣ��ɼ�\n");
    printf("4:�޸���ѧ�ɼ�   5:�޸������ɼ�   6:�޸�C���Գɼ�\n");
    printf("input your choice:");
    scanf("%d",&n);
    switch(n){
         case 1:
         f_cor(head,n); break;
         case 2:
         f_cor(head,n); break;
         case 3:
         f_cor(head,n); break;
         case 4:
         f_cor(head,n); break;
         case 5:
         f_cor(head,n); break;
         case 6:
         f_cor(head,n); break;
         default:printf("Worry!\n");
    }
    printf("�޸ĺ�����ݣ�\n");
    f_pri(head);
    f_sum(head);
    f_avr(head);
    return 0;

}
