#include "stdio.h"
void main(void)
{
    float i,*p=&i;
    scanf("%f",p);
    printf("%f\n",*p);
}
