#include <stdio.h>
#include <string.h>
#include <stdlib.h>
struct score_tab{
     long num;
     char name[20];
     float eng,math,phy,C;
     float sum;
     float avr;
     struct score_tab *next;
};

struct score_tab * f_int(struct score_tab *headp){
     struct score_tab *loc_head=NULL,*tail;
     long n;
     printf("����ѧ�ţ�������Ӣ���ѧ��������C���Գɼ�\n");
     scanf("%ld",&n);
     loc_head=(struct score_tab *)malloc(sizeof(struct score_tab));
     loc_head->num=n;
          scanf("%s%f%f%f%f",loc_head->name,&loc_head->eng,&loc_head->math,&loc_head->phy,&loc_head->C);
          loc_head->next=NULL;
          tail=loc_head;
          headp=loc_head;
          while(scanf("%ld",&n)&&n){
               loc_head=(struct score_tab *)malloc(sizeof(struct score_tab));
               loc_head->num=n;
               scanf("%s%f%f%f%f",loc_head->name,&loc_head->eng,&loc_head->math,&loc_head->phy,&loc_head->C);
               loc_head->next=NULL;
               tail->next=loc_head;
               tail=tail->next;
          }
     return headp;
}
void f_pri(struct score_tab *headp)
{
     struct score_tab *tail;
     tail=headp;
     while(tail!=NULL){
     printf("%ld   %s   %.2f   %.2f   %.2f   %.2f\n",tail->num,tail->name,tail->eng,tail->math,tail->phy,tail->C);
     tail=tail->next;
     }
}
struct score_tab * f_order(struct score_tab *headp){
     struct score_tab *a=headp;
     while(a!=NULL){
          a->sum=a->eng+a->math+a->phy+a->C;
          a->avr=a->sum/4.0;
          a=a->next;
     }
     struct score_tab *loc_head,*p,*p1,*p2;
     loc_head=(struct score_tab *)malloc(sizeof(struct score_tab));
     loc_head->next=headp;
     headp=headp->next;
     loc_head->next->next=NULL;
     while(headp!=NULL){
          p=headp;
          headp=headp->next;
          p->next=NULL;
          p2=loc_head;
          p1=loc_head->next;
          while(p1!=NULL&&p->avr>p1->avr){
               p2=p1;
               p1=p1->next;
          }
          if(p1!=NULL){
               p->next=p1;
               p2->next=p;
          }
          else p2->next=p;
     }
     headp=loc_head->next;
     free(loc_head);
     return headp;
}
void f_avr(struct score_tab *headp){
     struct score_tab *p=headp;
     while(p!=NULL){
          p->sum=p->eng+p->math+p->phy+p->C;
          p->avr=p->sum/4.0;
          printf("%s��ƽ����%.2f\n",p->name,p->avr);
          p=p->next;
     }
}

int main()
{
    struct score_tab *headp=NULL;
    headp=f_int(headp);
    f_avr(headp);
    headp=f_order(headp);
    printf("�����:\n");
    f_pri(headp);
    return 0;
}
