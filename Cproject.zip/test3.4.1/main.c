#include <stdio.h>
#include <stdlib.h>

int ans(int a,int b){
    int c;
    c=a%b;
    if(!c)
    return b;
    else{
        a=b;
        b=c;
        return ans(a,b);
    }
}
int main(void)
{
    int a,b;
    scanf("%d%d",&a,&b);
    printf("%d",ans(a,b));
    return 0;
}
