#include <stdio.h>
#include <string.h>
#include <stdlib.h>
struct score_tab{
     long num;
     char name[20];
     float eng,math,phy,C;
     float sum;
     float avr;
     struct score_tab *next;
};

struct score_tab * f_int(struct score_tab *headp){
     struct score_tab *loc_head=NULL,*tail;
     long n;
     printf("����ѧ�ţ�������Ӣ���ѧ��������C���Գɼ�\n");
     scanf("%ld",&n);
     loc_head=(struct score_tab *)malloc(sizeof(struct score_tab));
     loc_head->num=n;
          scanf("%s%f%f%f%f",loc_head->name,&loc_head->eng,&loc_head->math,&loc_head->phy,&loc_head->C);
          loc_head->next=NULL;
          tail=loc_head;
          headp=loc_head;
          while(scanf("%ld",&n)&&n){
               loc_head=(struct score_tab *)malloc(sizeof(struct score_tab));
               loc_head->num=n;
               scanf("%s%f%f%f%f",loc_head->name,&loc_head->eng,&loc_head->math,&loc_head->phy,&loc_head->C);
               loc_head->next=NULL;
               tail->next=loc_head;
               tail=tail->next;
          }
     return headp;
}
void f_pri(struct score_tab *headp)
{
     struct score_tab *tail;
     tail=headp;
     while(tail!=NULL){
     printf("%ld   %s   %.2f   %.2f   %.2f   %.2f\n",tail->num,tail->name,tail->eng,tail->math,tail->phy,tail->C);
     tail=tail->next;
     }
}
void f_cor(struct score_tab *headp,int n){
     struct score_tab *p=headp;
     char N[20],M[20],t[20];
     long a,b,c,d,e,f;
     int i;
     float eng1,math1,phy1,C1;
     switch(n){
          case 1://�޸�ѧ��
          scanf("%s",N);
          i=0;
          while(p->name[i]!=*(N+i++)&&p!=NULL)
          p=p->next;
          if(p==NULL) printf("Worry!\n");
          else{
               scanf("%ld",&a);
               p->num=a;
          } break;
          case 2://�޸�����

          scanf("%ld",&b);
          while(p->num!=b&&p!=NULL)
          p=p->next;
          if(p==NULL) printf("Worry!\n");
          else{
               gets(M);
               strcpy(t,M),strcpy(p->name,t),strcpy(M,p->name);
          } break;
          case 3://�޸�Ӣ��ɼ�
          scanf("%ld",&c);
          while(p->num!=c&&p!=NULL)
          p=p->next;
          if(p==NULL) printf("Worry!\n");
          else{
               scanf("%f",&eng1);
               p->eng=eng1;
          } break;
          case 4://�޸���ѧ�ɼ�
          scanf("%ld",&d);
          while(p->num!=d&&p!=NULL)
          p=p->next;
          if(p==NULL) printf("Worry!\n");
          else{
               scanf("%f",&math1);
               p->math=math1;
          } break;
          case 5://�޸������ɼ�

          scanf("%ld",&e);
          while(p->num!=e&&p!=NULL)
          p=p->next;
          if(p==NULL) printf("Worry!\n");
          else{
               scanf("%f",&phy1);
               p->phy=phy1;
          } break;
          case 6://�޸�C���Գɼ�
          scanf("%ld",&f);
          while(p->num!=f&&p!=NULL)
          p=p->next;
          if(p==NULL) printf("Worry!\n");
          else{
               scanf("%f",&C1);
               p->C=C1;
          } break;
          default:printf("Worry!\n"); break;

     }
}
void f_sum(struct score_tab *headp){
     struct score_tab *p;
     p=headp;
     while(p!=NULL){
          p->sum=p->eng+p->math+p->phy+p->C;
          printf("  %s ���ܷ�%.2f\n",p->name,p->sum);
          p=p->next;
     }
}
void f_avr(struct score_tab *headp){
     struct score_tab *p=headp;
     while(p!=NULL){
          p->sum=p->eng+p->math+p->phy+p->C;
          p->avr=p->sum/4.0;
          printf("  %s ��ƽ����%.2f\n",p->name,p->avr);
          p=p->next;
     }

}
int main()
{
    struct score_tab *headp=NULL;
    headp=f_int(headp);
    f_pri(headp);
    int n;
    printf("�������޸�ѡ��:\n");
    printf("1:�޸�ѧ��       2:�޸�����       3:�޸�Ӣ��ɼ�\n");
    printf("4:�޸���ѧ�ɼ�   5:�޸������ɼ�   6:�޸�C���Գɼ�\n");
    printf("input your choice:");
    scanf("%d",&n);
    switch(n){
         case 1:
         f_cor(headp,n); break;
         case 2:
         f_cor(headp,n); break;
         case 3:
         f_cor(headp,n); break;
         case 4:
         f_cor(headp,n); break;
         case 5:
         f_cor(headp,n); break;
         case 6:
         f_cor(headp,n); break;
         default:printf("Worry!\n");
    }
    printf("�޸ĺ�����ݣ�\n");
    f_pri(headp);
    f_sum(headp);
    f_avr(headp);
    return 0;

}
