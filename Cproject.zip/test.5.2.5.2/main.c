#include<stdio.h>
void try(int n,int a[8][8],int b[]){
     static int m=0;
     int i,j,k,l;
     for(i=0;i<8;i++){
          b[n]=0;
        for(j=0;j<n;j++)
            if((i==b[j])||(i-b[j]==n-j)||(i-b[j]==j-n)) b[n]=-1;
        if(b[n]==-1) continue;
        b[n]=i;
        a[n][i]=1;
        if(n<7)
        {
            try(n+1,a,b);
            if(b[n+1]==-1)
            {
                b[n]=-1;
                a[n][i]=0;
            }
        }
        else if(b[n]!=-1)
        {
            for(k=0;k<8;k++)
            {
                for(l=0;l<8;l++)
                    printf("%d",a[k][l]);
                printf("\n");
            }
            a[n][i]=0;
            m=m+1;
            printf("%d\n\n",m);
        }
    }
}
int main()
{
    int b[8],a[8][8]={0};
    try(0,a,b);
    return 0;
}


