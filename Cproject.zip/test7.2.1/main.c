#include<stdio.h>
#include<string.h>
int main(void) {
      char u[]="UVWXYZ";
      char v[]="xyz";
      struct T{
           int x;
           char c;
           char *t;
           }a[]={{11,'A',u},{100,'B',v}},*p=a;
           printf("1.(++p)->x\t%d\n",(++p)->x);
           p=a;
           printf("2.p++,p->c\t%c\n",(p++,p->c));
           p=a;
           printf("3.*p++->t,*p->t\t%c\n",(*p++->t,*p->t));
           p=a;
           printf("4.*(++p)->t\t%c\n",(*(++p)->t));
           p=a;
           printf("5.*++p->t\t%c\n",(*++p->t));
           --p->t, p=a;
           printf("6.++*p->t\t%c\n",(++*p->t));
           return 0;
}
